#include "client.h"

void client_start(sqlite3 *db,int sfd)
{
	char choose;
	char buf[1024];
	int res;
	while (1)
	{
		printf("\n");

		printf("******************************\n");
		printf("**        1.普通用户        **\n");
		printf("**        2.root用户        **\n");
		printf("**        3.退出            **\n");
		printf("******************************\n");
		printf("请输入(数字)>>>");
		scanf("%s",&choose);
		send(sfd, &choose, sizeof(choose), 0);
		switch (choose)
		{
		case '1':
			printf("请输入用户名:");scanf("%s", people_t.name);
			bzero(buf, sizeof(buf));strcpy(buf,people_t.name);
			send(sfd, buf, sizeof(buf), 0);
			
			printf("请输入密码:");scanf("%s", people_t.password);
			bzero(buf, sizeof(buf));strcpy(buf,people_t.password);
			send(sfd, buf, sizeof(buf), 0);

			bzero(buf, sizeof(buf));
			res = recv(sfd, buf, sizeof(buf), 0);
			printf("%s",buf);
			if(strcmp(buf,"亲爱的用户，欢迎您登陆员工管理系统！\n") == 0)
			{
				client_user_common(db,sfd);
				}
			break;
		case '2':
			printf("请输入用户名:");scanf("%s", people_t.name);
			bzero(buf, sizeof(buf));strcpy(buf,people_t.name);
			send(sfd, buf, sizeof(buf), 0);
			
			printf("请输入密码:");scanf("%s", people_t.password);
			bzero(buf, sizeof(buf));strcpy(buf,people_t.password);
			send(sfd, buf, sizeof(buf), 0);

			bzero(buf, sizeof(buf));
			res = recv(sfd, buf, sizeof(buf), 0);
			printf("%s",buf);
			if(strcmp(buf,"亲爱的管理员，欢迎您登陆员工管理系统！\n") == 0)
			{
				client_user_root(db,sfd);
				}
			break;
		case '3':
			goto END;
			break;
		default:
			bzero(buf, sizeof(buf));
			res = recv(sfd, buf, sizeof(buf), 0);
		}

	}

END:
	if (sqlite3_close(db) != SQLITE_OK)
	{
		return;
	}
}
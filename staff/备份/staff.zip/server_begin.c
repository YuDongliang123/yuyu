#include "server.h"

void server_start(sqlite3 *db,int sfd)
{
	char choose = 0;
	char buf[1024];
	int res;
	while (1)
	{
		res = recv(sfd, &choose, sizeof(choose), 0);
		switch (choose)
		{
		case '1':
			bzero(buf, sizeof(buf));
			res = recv(sfd, buf, sizeof(buf), 0);
			strcpy(people_t.name,buf);

			bzero(buf, sizeof(buf));
			res = recv(sfd, buf, sizeof(buf), 0);
			strcpy(people_t.password,buf);

			sprintf(sql, "select * from member where (name = \"%s\" and password = \"%s\");",people_t.name,people_t.password);
			ret = sqlite3_get_table(db, sql, &dbResult, &row, &col, &errmsg);
			if(row==0 && col==0)
			{
				strcpy(buf,"------Common user login error------\n");
				printf("%s",buf);sprintf(sql,"insert into history values (datetime('now'),'%s');",buf);
				if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK);
				bzero(buf, sizeof(buf));strcpy(buf,"用户名或密码错误!!!\n");send(sfd, buf, sizeof(buf), 0);
				continue;
			}
			sqlite3_free_table(dbResult);
			sprintf(sql, "select * from member where (name = \"%s\" and password = \"%s\" and user = \"common\");",people_t.name,people_t.password);
			ret = sqlite3_get_table(db, sql, &dbResult, &row, &col, &errmsg);
			if(row==0 && col==0)
			{
				bzero(buf, sizeof(buf));strcpy(buf,"非普通用户!!!\n");send(sfd, buf, sizeof(buf), 0);
				continue;
			}
			sqlite3_free_table(dbResult);
			bzero(buf, sizeof(buf));strcpy(buf,"亲爱的用户，欢迎您登陆员工管理系统！\n");send(sfd, buf, sizeof(buf), 0);
			sprintf(buf,"------Common user %s login succeeded------\n",people_t.name);
			printf("%s",buf);sprintf(sql,"insert into history values (datetime('now'),'%s');",buf);
			if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK);
			server_user_common(db,sfd);
			break;
		case '2':
			bzero(buf, sizeof(buf));
			res = recv(sfd, buf, sizeof(buf), 0);
			strcpy(people_t.name,buf);

			bzero(buf, sizeof(buf));
			res = recv(sfd, buf, sizeof(buf), 0);
			strcpy(people_t.password,buf);

			sprintf(sql, "select * from member where (name = \"%s\" and password = \"%s\");",people_t.name,people_t.password);
			ret = sqlite3_get_table(db, sql, &dbResult, &row, &col, &errmsg);
			if(row==0 && col==0)
			{
				strcpy(buf,"------Admin user login error------\n");
				printf("%s",buf);sprintf(sql,"insert into history values (datetime('now'),'%s');",buf);
				if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK);
				bzero(buf, sizeof(buf));strcpy(buf,"用户名或密码错误!!!\n");send(sfd, buf, sizeof(buf), 0);
				continue;
			}
			sqlite3_free_table(dbResult);
			sprintf(sql, "select * from member where (name = \"%s\" and password = \"%s\" and user = \"root\");",people_t.name,people_t.password);
			ret = sqlite3_get_table(db, sql, &dbResult, &row, &col, &errmsg);
			if(row==0 && col==0)
			{
				bzero(buf, sizeof(buf));strcpy(buf,"非管理员用户!!!\n");send(sfd, buf, sizeof(buf), 0);
				continue;
			}
			sqlite3_free_table(dbResult);
			bzero(buf, sizeof(buf));strcpy(buf,"亲爱的管理员，欢迎您登陆员工管理系统！\n");send(sfd, buf, sizeof(buf), 0);
			sprintf(buf,"------Admin user %s login succeeded------\n",people_t.name);
			printf("%s",buf);sprintf(sql,"insert into history values (datetime('now'),'%s');",buf);
			if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK);
			server_user_root(db,sfd);
		case '3':
			goto END;
			break;
		default:
			bzero(buf, sizeof(buf));strcpy(buf,"输入错误，请重新输入\n");send(sfd, buf, sizeof(buf), 0);
		}

	}

END:
	if (sqlite3_close(db) != SQLITE_OK)
	{
		return;
	}
}